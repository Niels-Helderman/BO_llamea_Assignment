import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import norm
from scipy.stats import qmc

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        self.tr_size = 0.5
        kernel = ConstantKernel(1.0) * Matern(length_scale=np.ones(dim), nu=2.5) + WhiteKernel(noise_level=1e-3)
        self.gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=3, normalize_y=False)

    def __call__(self, func):
        lb, ub = np.array(func.bounds.lb), np.array(func.bounds.ub)
        # Use Latin Hypercube Sampling for better initial coverage
        n_init = min(self.budget, 2 * self.dim + 2)
        sampler = qmc.LatinHypercube(d=self.dim)
        sample = sampler.random(n=n_init)
        init_points = qmc.scale(sample, lb, ub)
        
        for i in range(n_init):
            x = init_points[i]
            self._update(x, func(x))

        while len(self.y) < self.budget:
            try:
                y_min, y_range = np.min(self.y), max(np.ptp(self.y), 1e-8)
                y_norm = (self.y - y_min) / y_range
                self.gp.fit(self.X, y_norm)
                
                # Trust region centered at best found
                center = self.best_x
                scale = np.clip(self.tr_size * (ub - lb), 0.01 * (ub - lb), 1.0 * (ub - lb))
                lb_tr, ub_tr = np.clip(center - scale, lb, ub), np.clip(center + scale, lb, ub)
                
                best_ei, x_next = -1.0, np.random.uniform(lb, ub)
                # Multi-start acquisition optimization
                for _ in range(8):
                    x0 = np.random.uniform(lb_tr, ub_tr)
                    res = minimize(lambda x: -self._ei(x, y_min, y_range), x0, 
                                   bounds=list(zip(lb, ub)), method='L-BFGS-B', tol=1e-3)
                    if -res.fun > best_ei:
                        best_ei, x_next = -res.fun, res.x
                
                old_best = self.best_y
                self._update(x_next, func(x_next))
                # Adaptive adjustment of trust region size
                self.tr_size = np.clip(self.tr_size * 1.1 if self.best_y < old_best else self.tr_size * 0.7, 0.05, 0.5)
            except:
                self._update(np.random.uniform(lb, ub), func(np.random.uniform(lb, ub)))
        return float(self.best_y), self.best_x

    def _ei(self, x, y_min, y_range):
        mu_norm, std_norm = self.gp.predict(x.reshape(1, -1), return_std=True)
        best_y_norm = (self.best_y - y_min) / y_range
        mu, std = mu_norm[0] * y_range + y_min, std_norm[0] * y_range
        if std <= 1e-12: return 0.0
        z = (self.best_y - mu) / std
        return (self.best_y - mu) * norm.cdf(z) + std * norm.pdf(z)

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y, self.best_x = y, x