import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import norm

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        self.tr_size = 0.5  # Initial trust region radius
        kernel = ConstantKernel(1.0) * Matern(length_scale=np.ones(dim), nu=2.5) + WhiteKernel(noise_level=1e-4)
        self.gp = GaussianProcessRegressor(kernel=kernel, alpha=0.0, normalize_y=False)

    def __call__(self, func):
        lb, ub = np.array(func.bounds.lb), np.array(func.bounds.ub)
        n_init = min(self.budget, 2 * self.dim + 2)
        
        for _ in range(n_init):
            x = np.random.uniform(lb, ub)
            self._update(x, func(x))

        while len(self.y) < self.budget:
            try:
                y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-8
                y_norm = (self.y - y_mean) / y_std
                self.gp.fit(self.X, y_norm)
                
                # Trust Region centered at incumbent
                center = self.best_x
                lb_tr = np.maximum(lb, center - self.tr_size * (ub - lb))
                ub_tr = np.minimum(ub, center + self.tr_size * (ub - lb))
                
                best_ei = -1.0
                x_next = np.random.uniform(lb, ub)
                
                for _ in range(8):
                    x0 = np.random.uniform(lb_tr, ub_tr)
                    res = minimize(lambda x: -self._ei(x, y_mean, y_std), x0, 
                                   bounds=list(zip(lb_tr, ub_tr)), method='L-BFGS-B')
                    if -res.fun > best_ei:
                        best_ei, x_next = -res.fun, res.x
                
                old_best = self.best_y
                self._update(x_next, func(x_next))
                
                # Simple TR adaptation
                if self.best_y < old_best:
                    self.tr_size = min(0.5, self.tr_size * 1.1)
                else:
                    self.tr_size *= 0.8
                if self.tr_size < 0.01: self.tr_size = 0.5 # Reset if too small
                    
            except:
                self._update(np.random.uniform(lb, ub), func(np.random.uniform(lb, ub)))
        
        return float(self.best_y), self.best_x

    def _ei(self, x, y_mean, y_std):
        mu, std = self.gp.predict(x.reshape(1, -1), return_std=True)
        mu = mu[0] * y_std + y_mean
        std = std[0] * y_std
        if std <= 1e-9: return 0.0
        z = (self.best_y - mu) / std
        return (self.best_y - mu) * norm.cdf(z) + std * norm.pdf(z)

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x