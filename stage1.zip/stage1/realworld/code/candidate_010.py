import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        # Use Matern kernel for flexibility in real-world landscapes
        kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e1)) + WhiteKernel(noise_level=1e-5)
        self.gp = GaussianProcessRegressor(kernel=kernel, alpha=0.0, n_restarts_optimizer=2)
        self.tr_size = 0.5

    def __call__(self, func):
        lb, ub = np.array(func.bounds.lb), np.array(func.bounds.ub)
        
        # Initial LHS-like sampling
        n_init = max(2, min(self.budget // 10, 2 * self.dim + 2))
        for _ in range(n_init):
            x = np.random.uniform(lb, ub)
            self._update(x, func(x))

        while len(self.y) < self.budget:
            # Normalize y for stable GP regression
            y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-8
            y_norm = (self.y - y_mean) / y_std
            
            try:
                self.gp.fit(self.X, y_norm)
                
                # Adaptive UCB beta: starts high for exploration, decays
                beta = 2.0 * np.sqrt(np.log(len(self.y) + 1))
                
                # Trust-region constrained optimization to avoid stagnation
                best_val = -np.inf
                x_next = np.random.uniform(lb, ub)
                
                for _ in range(10):
                    x_start = np.clip(self.best_x + np.random.normal(0, self.tr_size, self.dim), 0, 1) if self.best_x is not None else np.random.uniform(0, 1)
                    res = minimize(lambda x: -self._ucb(x, y_mean, y_std, beta), x_start, 
                                   bounds=[(0, 1)] * self.dim, method='L-BFGS-B')
                    if -res.fun > best_val:
                        best_val, x_next = -res.fun, res.x
                
                val = func(x_next * (ub - lb) + lb)
                self._update(x_next * (ub - lb) + lb, val)
                
                # TR heuristic
                self.tr_size = np.clip(self.tr_size * 1.05 if val < self.best_y else self.tr_size * 0.95, 0.05, 0.5)
            except:
                # Robust fallback
                x_rand = np.random.uniform(lb, ub)
                self._update(x_rand, func(x_rand))
        
        return float(self.best_y), self.best_x

    def _ucb(self, x, y_mean, y_std, beta):
        mu, std = self.gp.predict(x.reshape(1, -1), return_std=True)
        # Convert back to unnormalized scale for UCB
        return -(mu[0] * y_std + y_mean) + beta * (std[0] * y_std)

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x