import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        # GP kernel: Matern 5/2 is robust for real-world black-box functions
        kernel = ConstantKernel(1.0) * Matern(length_scale=np.ones(dim), nu=2.5) + WhiteKernel(noise_level=1e-5)
        self.gp = GaussianProcessRegressor(kernel=kernel, alpha=0.0, normalize_y=False, n_restarts_optimizer=0)

    def _get_ei(self, x, gp, best_y):
        mu, std = gp.predict(x.reshape(1, -1), return_std=True)
        if std <= 1e-12: return 0.0
        z = (best_y - mu) / std
        from scipy.stats import norm
        return (best_y - mu) * norm.cdf(z) + std * norm.pdf(z)

    def __call__(self, func):
        lb, ub = func.bounds.lb, func.bounds.ub
        
        # Initial exploration: Latin Hypercube-like sampling via low-discrepancy initialization
        n_init = min(self.budget, 2 * self.dim + 2)
        for _ in range(n_init):
            x = np.random.uniform(lb, ub)
            y = func(x)
            self._update(x, y)
        
        # Optimization loop
        while len(self.y) < self.budget:
            try:
                # Standardize data for GP stability
                y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-8
                y_norm = (self.y - y_mean) / y_std
                self.gp.fit(self.X, y_norm)
                
                # Acquisition optimization
                best_x = None
                max_ei = -1.0
                for _ in range(5):
                    x0 = np.random.uniform(lb, ub)
                    res = minimize(lambda x: -self._get_ei(x, self.gp, (self.best_y - y_mean)/y_std), 
                                   x0, bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if -res.fun > max_ei:
                        max_ei, best_x = -res.fun, res.x
                x_next = best_x
            except:
                x_next = np.random.uniform(lb, ub)
            
            self._update(x_next, func(x_next))
            
        return float(self.best_y), self.best_x

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x