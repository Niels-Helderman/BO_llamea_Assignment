import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import norm

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        kernel = ConstantKernel(1.0) * Matern(length_scale=np.ones(dim), nu=2.5) + WhiteKernel(noise_level=1e-5)
        self.gp = GaussianProcessRegressor(kernel=kernel, alpha=0.0, normalize_y=False, n_restarts_optimizer=2)

    def _get_ei(self, x, gp, best_y_norm):
        mu, std = gp.predict(x.reshape(1, -1), return_std=True)
        std = np.maximum(std, 1e-9)
        z = (best_y_norm - mu) / std
        return (best_y_norm - mu) * norm.cdf(z) + std * norm.pdf(z)

    def __call__(self, func):
        lb, ub = func.bounds.lb, func.bounds.ub
        n_init = min(self.budget, 2 * self.dim + 4)
        
        for i in range(n_init):
            x = lb + (ub - lb) * (np.random.rand(self.dim) if i > 0 else 0.5)
            self._update(x, func(x))
            
        while len(self.y) < self.budget:
            y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-8
            y_norm = (self.y - y_mean) / y_std
            best_y_norm = (self.best_y - y_mean) / y_std
            
            try:
                # Refit hyperparameters every few steps to save budget
                if len(self.y) % 5 == 0:
                    self.gp.fit(self.X, y_norm)
                else:
                    self.gp.kernel_ = self.gp.kernel_
                    self.gp.fit(self.X, y_norm)

                best_x, max_ei = None, -1.0
                # Multiple starts for acquisition optimization
                for _ in range(8):
                    x0 = np.random.uniform(lb, ub)
                    res = minimize(lambda x: -self._get_ei(x, self.gp, best_y_norm), 
                                   x0, bounds=list(zip(lb, ub)), method='L-BFGS-B', tol=1e-4)
                    if -res.fun > max_ei:
                        max_ei, best_x = -res.fun, res.x
                x_next = best_x
            except:
                x_next = np.random.uniform(lb, ub)
            
            self._update(x_next, func(x_next))
            
        return float(self.best_y), self.best_x

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x