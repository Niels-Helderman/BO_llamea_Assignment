import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import norm

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        # Using ARD kernel for better feature relevance handling
        kernel = ConstantKernel(1.0) * Matern(length_scale=np.ones(dim), nu=2.5) + WhiteKernel(noise_level=1e-5)
        self.gp = GaussianProcessRegressor(kernel=kernel, alpha=0.0, n_restarts_optimizer=2)

    def __call__(self, func):
        lb, ub = np.array(func.bounds.lb), np.array(func.bounds.ub)
        
        # 1. Initialization: LHS-like uniform sampling
        n_init = min(self.budget, 2 * self.dim + 4)
        for _ in range(n_init):
            x = np.random.uniform(lb, ub)
            self._update(x, func(x))

        # 2. Main Optimization Loop
        while len(self.y) < self.budget:
            try:
                # Log-transform y to handle non-stationary objective scales
                y_min = np.min(self.y)
                y_shift = np.abs(y_min) + 1e-6
                y_log = np.log(self.y + y_shift)
                
                # Periodically re-fit hyperparameters to save compute
                self.gp.fit(self.X, y_log)
                
                # Global acquisition optimization (EI)
                best_ei = -1.0
                x_next = np.random.uniform(lb, ub)
                
                for _ in range(10):
                    x0 = np.random.uniform(lb, ub)
                    res = minimize(lambda x: -self._ei(x, y_shift), x0, 
                                   bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if -res.fun > best_ei:
                        best_ei, x_next = -res.fun, res.x
                
                self._update(x_next, func(x_next))
            except:
                # Fallback on failure
                self._update(np.random.uniform(lb, ub), func(np.random.uniform(lb, ub)))
        
        return float(self.best_y), self.best_x

    def _ei(self, x, y_shift):
        # Predict on log scale
        mu_log, std_log = self.gp.predict(x.reshape(1, -1), return_std=True)
        # Convert back to original scale (approximate mean via log-normal properties)
        mu = np.exp(mu_log[0] + 0.5 * std_log[0]**2) - y_shift
        std = np.sqrt((np.exp(std_log[0]**2) - 1) * np.exp(2 * mu_log[0] + std_log[0]**2))
        
        if std <= 1e-9: return 0.0
        z = (self.best_y - mu) / std
        return (self.best_y - mu) * norm.cdf(z) + std * norm.pdf(z)

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x