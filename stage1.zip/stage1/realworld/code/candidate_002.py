import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, WhiteKernel, ConstantKernel
from scipy.stats import norm
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X_hist = []
        self.y_hist = []
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=np.ones(dim)) + WhiteKernel(noise_level=1e-3)
        self.gpr = GaussianProcessRegressor(kernel=self.kernel, alpha=0, n_restarts_optimizer=0, normalize_y=False)

    def _scale(self, x, lb, ub):
        return (x - lb) / (ub - lb + 1e-12)

    def _unscale(self, x_norm, lb, ub):
        return x_norm * (ub - lb) + lb

    def _acquisition(self, x_norm, gpr, y_min):
        mu, sigma = gpr.predict(x_norm.reshape(1, -1), return_std=True)
        sigma = np.maximum(sigma, 1e-12)
        with np.errstate(divide='ignore'):
            z = (y_min - mu) / sigma
            ei = (y_min - mu) * norm.cdf(z) + sigma * norm.pdf(z)
        return -ei[0]

    def __call__(self, func):
        lb, ub = func.bounds.lb, func.bounds.ub
        
        # Initial exploration: Latin Hypercube-like start
        for i in range(min(self.budget, 2 * self.dim + 2)):
            x = np.random.uniform(lb, ub)
            y = func(x)
            self.X_hist.append(self._scale(x, lb, ub))
            self.y_hist.append(y)

        while len(self.X_hist) < self.budget:
            X = np.array(self.X_hist)
            y = np.array(self.y_hist)
            y_min = np.min(y)
            
            # Standardize y for stability
            y_mean, y_std = np.mean(y), np.std(y) + 1e-8
            y_norm = (y - y_mean) / y_std
            
            try:
                self.gpr.fit(X, y_norm)
                
                # Global optimization of acquisition function
                best_ei = np.inf
                next_x_norm = np.random.rand(self.dim)
                
                for _ in range(5):
                    x0 = np.random.rand(self.dim)
                    res = minimize(self._acquisition, x0, args=(self.gpr, (y_min - y_mean) / y_std),
                                   bounds=[(0, 1)] * self.dim, method='L-BFGS-B')
                    if res.fun < best_ei:
                        best_ei = res.fun
                        next_x_norm = res.x
            except:
                next_x_norm = np.random.rand(self.dim)
            
            x_next = self._unscale(next_x_norm, lb, ub)
            y_next = func(x_next)
            self.X_hist.append(next_x_norm)
            self.y_hist.append(y_next)

        idx = np.argmin(self.y_hist)
        return float(self.y_hist[idx]), self._unscale(self.X_hist[idx], lb, ub)