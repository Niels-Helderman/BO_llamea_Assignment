import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import norm
from scipy.stats import qmc

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        self.tr_size = 0.5
        # Kernel with length-scale prior and jitter to handle numerical instabilities
        kernel = ConstantKernel(1.0) * Matern(length_scale=np.ones(dim), nu=2.5) + WhiteKernel(noise_level=1e-6)
        self.gp = GaussianProcessRegressor(kernel=kernel, alpha=0.0, normalize_y=False, n_restarts_optimizer=2)

    def __call__(self, func):
        lb, ub = np.array(func.bounds.lb), np.array(func.bounds.ub)
        # Increased initial sampling for better global coverage
        n_init = min(self.budget, 2 * self.dim + 8)
        sampler = qmc.Sobol(d=self.dim, scramble=True)
        init_points = lb + (ub - lb) * sampler.random(n_init)
        
        for x in init_points:
            if len(self.y) >= self.budget: break
            self._update(x, func(x))

        while len(self.y) < self.budget:
            try:
                y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-9
                self.gp.fit(self.X, (self.y - y_mean) / y_std)
                
                # Trust-region approach to force local search around the current best
                lb_tr = np.maximum(lb, self.best_x - self.tr_size * (ub - lb))
                ub_tr = np.minimum(ub, self.best_x + self.tr_size * (ub - lb))
                
                best_ei, x_next = -1.0, np.random.uniform(lb, ub)
                # Multi-start optimization of the acquisition function
                for _ in range(8):
                    x0 = np.random.uniform(lb_tr, ub_tr)
                    res = minimize(lambda x: -self._ei(x, y_mean, y_std), x0, 
                                   bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if -res.fun > best_ei:
                        best_ei, x_next = -res.fun, res.x
                
                old_best = self.best_y
                self._update(x_next, func(x_next))
                # Adaptive control of TR size
                self.tr_size = np.clip(self.tr_size * 1.1 if self.best_y < old_best else self.tr_size * 0.7, 0.05, 0.5)
            except:
                # Robust fallback for GP failure
                self._update(np.random.uniform(lb, ub), func(np.random.uniform(lb, ub)))
        
        return float(self.best_y), self.best_x

    def _ei(self, x, y_mean, y_std):
        mu, std = self.gp.predict(x.reshape(1, -1), return_std=True)
        mu, std = mu[0] * y_std + y_mean, std[0] * y_std
        if std <= 1e-12: return 0.0
        z = (self.best_y - mu) / std
        return (self.best_y - mu) * norm.cdf(z) + std * norm.pdf(z)

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y, self.best_x = float(y), x