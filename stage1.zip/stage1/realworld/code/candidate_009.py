import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import norm

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        self.tr_size = 0.5
        # Matern 2.5 is robust for general black-box functions
        kernel = ConstantKernel(1.0) * Matern(length_scale=np.ones(dim), nu=2.5) + WhiteKernel(noise_level=1e-5)
        self.gp = GaussianProcessRegressor(kernel=kernel, alpha=0.0, normalize_y=False, n_restarts_optimizer=0)

    def __call__(self, func):
        lb, ub = np.array(func.bounds.lb), np.array(func.bounds.ub)
        
        # Latin Hypercube Sampling (LHS) for better coverage in first 2*dim + 2 evaluations
        n_init = min(self.budget, 2 * self.dim + 2)
        for i in range(n_init):
            x = lb + (ub - lb) * (np.random.rand(self.dim) if i == 0 else (np.random.rand(self.dim) + np.arange(self.dim)) / self.dim % 1.0)
            self._update(x, func(x))

        while len(self.y) < self.budget:
            try:
                y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-8
                self.gp.fit(self.X, (self.y - y_mean) / y_std)
                
                center = self.best_x
                # Trust Region constraint
                lb_tr = np.maximum(lb, center - self.tr_size * (ub - lb))
                ub_tr = np.minimum(ub, center + self.tr_size * (ub - lb))
                
                best_ei = -1.0
                x_next = np.random.uniform(lb, ub)
                
                # Multi-start acquisition optimization
                for _ in range(10):
                    x0 = np.random.uniform(lb_tr, ub_tr)
                    res = minimize(lambda x: -self._ei(x, y_mean, y_std), x0, 
                                   bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if -res.fun > best_ei:
                        best_ei, x_next = -res.fun, res.x
                
                old_best = self.best_y
                self._update(x_next, func(x_next))
                
                # TR adaptation: expand if successful, contract if failed
                if self.best_y < old_best:
                    self.tr_size = min(0.5, self.tr_size * 1.2)
                else:
                    self.tr_size = max(0.01, self.tr_size * 0.7)
            except:
                self._update(np.random.uniform(lb, ub), func(np.random.uniform(lb, ub)))
        
        return float(self.best_y), self.best_x

    def _ei(self, x, y_mean, y_std):
        mu, std = self.gp.predict(x.reshape(1, -1), return_std=True)
        mu = mu[0] * y_std + y_mean
        std = std[0] * y_std
        if std <= 1e-12: return 0.0
        z = (self.best_y - mu) / std
        return (self.best_y - mu) * norm.cdf(z) + std * norm.pdf(z)

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x