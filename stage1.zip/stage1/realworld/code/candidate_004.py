import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        # Using Matern 5/2 as it is generally well-suited for non-smooth physical systems
        self.kernel = ConstantKernel(1.0) * Matern(length_scale=np.ones(dim), nu=2.5) + WhiteKernel(noise_level=1e-6)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=0.0, normalize_y=False, n_restarts_optimizer=0)

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x

    def __call__(self, func):
        lb, ub = func.bounds.lb, func.bounds.ub
        
        # Initial exploration: Latin Hypercube-like via randomized offsets
        n_init = min(self.budget, 2 * self.dim + 4)
        for i in range(n_init):
            x = lb + (ub - lb) * (np.random.rand(self.dim) if i > 0 else 0.5)
            self._update(x, func(x))
        
        while len(self.y) < self.budget:
            try:
                # Standardize for numerical stability
                y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-8
                y_norm = (self.y - y_mean) / y_std
                
                # Periodically re-fit hyperparameters to ensure model quality
                self.gp.fit(self.X, y_norm)
                
                # Adaptive UCB: beta decreases as we gain more information
                t = len(self.y)
                beta = np.sqrt(2.0 * np.log(t + 1))
                
                def ucb(x):
                    x = x.reshape(1, -1)
                    mu, std = self.gp.predict(x, return_std=True)
                    # Minimize: - (mean - beta * std) => -(mu - beta*std)
                    return -(mu - beta * std)

                # Multistart L-BFGS-B optimization of the acquisition function
                best_x_next = None
                min_acq = np.inf
                for _ in range(8):
                    x0 = np.random.uniform(lb, ub)
                    res = minimize(ucb, x0, bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if res.fun < min_acq:
                        min_acq, best_x_next = res.fun, res.x
                x_next = best_x_next
            except:
                # Fallback on failure
                x_next = np.random.uniform(lb, ub)
            
            self._update(x_next, func(x_next))
            
        return float(self.best_y), self.best_x