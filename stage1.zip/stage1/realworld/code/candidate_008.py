import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e1)) + WhiteKernel(noise_level=1e-5)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=1e-10, normalize_y=False, n_restarts_optimizer=0)

    def __call__(self, func):
        lb, ub = np.array(func.bounds.lb), np.array(func.bounds.ub)
        
        # Initialization using Latin Hypercube Sampling logic
        n_init = min(self.budget, 2 * self.dim + 4)
        for i in range(n_init):
            x = lb + (ub - lb) * (np.random.rand(self.dim) if i > 0 else 0.5)
            self._update(x, func(x))

        while len(self.y) < self.budget:
            try:
                # Standardize y for GP
                y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-8
                y_norm = (self.y - y_mean) / y_std
                
                # Periodically re-fit hyperparams, use warm start otherwise
                self.gp.fit(self.X, y_norm)
                
                # UCB with adaptive beta (logarithmic schedule)
                t = len(self.y)
                beta = np.sqrt(2 * np.log(t**2 * (np.pi**2) / 0.6))
                
                def acq(x):
                    mu, std = self.gp.predict(x.reshape(1, -1), return_std=True)
                    return -(mu[0] * y_std + y_mean - beta * (std[0] * y_std))

                # Hybrid Search: Multi-start L-BFGS-B
                x_next = lb + (ub - lb) * np.random.rand(self.dim)
                best_val = np.inf
                for _ in range(10):
                    x0 = lb + (ub - lb) * np.random.rand(self.dim)
                    res = minimize(acq, x0, bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if res.fun < best_val:
                        best_val, x_next = res.fun, res.x
                
                self._update(x_next, func(x_next))
            except:
                # Fallback to random search if GP fit or optimization fails
                self._update(np.random.uniform(lb, ub), func(np.random.uniform(lb, ub)))
        
        return float(self.best_y), self.best_x

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x