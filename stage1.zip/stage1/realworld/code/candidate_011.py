import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import norm

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        self.tr_size = 0.5
        # Use Matern 2.5 for smooth/complex boundaries, WhiteKernel for numerical stability
        kernel = ConstantKernel(1.0) * Matern(length_scale=np.ones(dim), nu=2.5) + WhiteKernel(noise_level=1e-5)
        self.gp = GaussianProcessRegressor(kernel=kernel, alpha=0.0, normalize_y=False, n_restarts_optimizer=0)

    def __call__(self, func):
        lb, ub = np.array(func.bounds.lb), np.array(func.bounds.ub)
        
        # Initial Latin Hypercube-like spread using Sobol-sequence-inspired initialization
        n_init = min(self.budget, 2 * self.dim + 4)
        for i in range(n_init):
            x = lb + (ub - lb) * (np.random.rand(self.dim))
            self._update(x, func(x))

        while len(self.y) < self.budget:
            try:
                y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-9
                y_norm = (self.y - y_mean) / y_std
                
                # Refit hyperparameters only periodically or when enough new data exists
                if len(self.y) % 5 == 0:
                    self.gp.fit(self.X, y_norm)
                else:
                    self.gp.fit(self.X, y_norm)

                # Trust Region centered at incumbent to focus exploitation
                center = self.best_x
                tr_lb = np.maximum(lb, center - self.tr_size * (ub - lb))
                tr_ub = np.minimum(ub, center + self.tr_size * (ub - lb))
                
                best_ei = -np.inf
                x_next = np.random.uniform(lb, ub)
                
                # Multi-start optimization of EI
                for _ in range(10):
                    x0 = np.random.uniform(tr_lb, tr_ub)
                    res = minimize(lambda x: -self._ei(x, y_mean, y_std), x0, 
                                   bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if -res.fun > best_ei:
                        best_ei, x_next = -res.fun, res.x
                
                old_best = self.best_y
                self._update(x_next, func(x_next))
                
                # Adaptive TR sizing
                if self.best_y < old_best:
                    self.tr_size = min(0.5, self.tr_size * 1.2)
                else:
                    self.tr_size = max(0.05, self.tr_size * 0.7)
                    
            except Exception:
                self._update(np.random.uniform(lb, ub), func(np.random.uniform(lb, ub)))
        
        return float(self.best_y), self.best_x

    def _ei(self, x, y_mean, y_std):
        mu, std = self.gp.predict(x.reshape(1, -1), return_std=True)
        mu = mu[0] * y_std + y_mean
        std = std[0] * y_std
        if std <= 1e-12: return 0.0
        z = (self.best_y - mu) / std
        return (self.best_y - mu) * norm.cdf(z) + std * norm.pdf(z)

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x