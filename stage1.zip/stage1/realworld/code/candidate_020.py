import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import qmc

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.X = np.empty((0, dim))
        self.y = np.empty((0,))
        self.best_y = np.inf
        self.best_x = None
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e1)) + WhiteKernel(noise_level=1e-5)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=0.0, n_restarts_optimizer=1)

    def __call__(self, func):
        lb, ub = np.array(func.bounds.lb), np.array(func.bounds.ub)
        
        # 1. Sobol Initialization
        n_init = min(self.budget, 2 * self.dim + 2)
        sampler = qmc.Sobol(d=self.dim, scramble=True)
        samples = sampler.random(n_init)
        init_points = lb + (ub - lb) * samples
        
        for x in init_points:
            self._update(x, func(x))

        # 2. Optimization loop
        while len(self.y) < self.budget:
            try:
                y_mean, y_std = np.mean(self.y), np.std(self.y) + 1e-8
                y_scaled = (self.y - y_mean) / y_std
                self.gp.fit(self.X, y_scaled)
                
                # Adaptive Beta for UCB: explore more early, exploit late
                beta = 2.0 * np.sqrt(np.log(len(self.y) + 1))
                
                def acq(x):
                    mu, std = self.gp.predict(x.reshape(1, -1), return_std=True)
                    return -(mu[0] - beta * std[0]) # Minimize UCB

                best_val, best_cand = np.inf, None
                for _ in range(8):
                    x0 = self.best_x + np.random.normal(0, 0.2 * (ub - lb))
                    res = minimize(acq, x0, bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if res.fun < best_val:
                        best_val, best_cand = res.fun, res.x
                
                self._update(best_cand, func(best_cand))
            except:
                # Fallback: random search if surrogate fails
                self._update(np.random.uniform(lb, ub), func(np.random.uniform(lb, ub)))
                
        return float(self.best_y), self.best_x

    def _update(self, x, y):
        self.X = np.vstack([self.X, x])
        self.y = np.append(self.y, y)
        if y < self.best_y:
            self.best_y = y
            self.best_x = x