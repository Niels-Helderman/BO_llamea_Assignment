import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.stats import norm
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Use Matern 5/2 for smoothness properties, fixed jitter to prevent numerical instability
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e1)) + WhiteKernel(noise_level=1e-8)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=1e-8, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        X_obs, y_obs = [], []
        best_y, best_x = np.inf, None

        # Increased initial sampling: use 15 samples (or 25% of budget) for better initial surrogate fit
        n_init = min(15, self.budget // 4)
        for i in range(n_init):
            x = lb + (ub - lb) * np.random.rand(self.dim)
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y, best_x = y, x

        # Sequential Model-Based Optimization
        for i in range(n_init, self.budget):
            X = (np.array(X_obs) - lb) / range_val
            y = np.array(y_obs)
            
            # Refit hyperparameters every 3 iterations to adapt as search space converges
            try:
                self.gp.optimizer = "fmin_l_bfgs_b" if (i % 3 == 0) else None
                self.gp.fit(X, y)
            except:
                pass # Continue with previous GP state if fitting fails

            def ei(x_norm):
                mu, sigma = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                sigma = np.maximum(sigma, 1e-12)
                diff = best_y - mu
                z = diff / sigma
                return -(diff * norm.cdf(z) + sigma * norm.pdf(z))

            best_acq = np.inf
            next_x_norm = np.random.rand(self.dim)
            # Multi-start acquisition optimization
            for _ in range(8):
                x0 = np.random.rand(self.dim)
                res = minimize(ei, x0, bounds=[(0, 1)] * self.dim, method='L-BFGS-B', tol=1e-4)
                if res.fun < best_acq:
                    best_acq, next_x_norm = res.fun, res.x

            next_x = lb + next_x_norm * range_val
            
            try:
                next_y = func(next_x)
            except:
                # Fallback to random search if objective evaluation fails
                next_x = lb + np.random.rand(self.dim) * range_val
                next_y = func(next_x)

            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y, best_x = next_y, next_x

        return float(best_y), best_x