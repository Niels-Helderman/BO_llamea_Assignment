import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.stats import norm
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=np.ones(dim)) + WhiteKernel(noise_level=1e-6)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=0.0, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        X_obs = []
        y_obs = []
        best_y = np.inf
        best_x = None

        # Initialization: Use a small portion of budget for space-filling design
        n_init = min(10, self.budget // 2)
        for i in range(n_init):
            x = lb + (ub - lb) * np.random.rand(self.dim)
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y = y
                best_x = x

        # Sequential Model-Based Optimization
        for i in range(n_init, self.budget):
            X = np.array(X_obs)
            y = np.array(y_obs)
            
            # Fit GP (re-optimize hyperparameters every 5 steps or initially)
            optimize_hyper = (i % 5 == 0)
            self.gp.optimizer = "fmin_l_bfgs_b" if optimize_hyper else None
            self.gp.fit((X - lb) / range_val, y)

            # Define Acquisition Function: Expected Improvement
            def ei(x_norm):
                mu, sigma = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                sigma = np.maximum(sigma, 1e-9)
                imp = best_y - mu
                z = imp / sigma
                return -(imp * norm.cdf(z) + sigma * norm.pdf(z))

            # Optimize Acquisition
            best_acq = np.inf
            next_x_norm = None
            for _ in range(5):
                x0 = np.random.rand(self.dim)
                res = minimize(ei, x0, bounds=[(0, 1)] * self.dim, method='L-BFGS-B')
                if res.fun < best_acq:
                    best_acq = res.fun
                    next_x_norm = res.x

            next_x = lb + next_x_norm * range_val
            next_y = func(next_x)

            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y = next_y
                best_x = next_x

        return float(best_y), best_x