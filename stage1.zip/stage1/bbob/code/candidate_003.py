import numpy as np
from sklearn.ensemble import RandomForestRegressor
from scipy.optimize import minimize
from scipy.stats import norm

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        # Use an ensemble surrogate (Random Forest) for better capture of 
        # non-stationary BBOB landscapes compared to standard stationary GPs.
        self.rf = RandomForestRegressor(n_estimators=50, min_samples_split=2, n_jobs=1)

    def _get_ei(self, x, rf, y_min, y_std_eps=1e-9):
        x = x.reshape(1, -1)
        # RF ensemble prediction: mean and variance (proxy for uncertainty)
        preds = np.array([tree.predict(x) for tree in rf.estimators_])
        mu = np.mean(preds)
        sigma = np.std(preds) + y_std_eps
        
        imp = y_min - mu
        z = imp / sigma
        return -(imp * norm.cdf(z) + sigma * norm.pdf(z))

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        
        x_obs, y_obs = [], []
        
        # Latin Hypercube-like initial sampling
        n_init = min(self.budget // 5, 2 * self.dim + 5)
        
        for i in range(self.budget):
            if i < n_init:
                x = lb + np.random.rand(self.dim) * (ub - lb)
            else:
                y_min = np.min(y_obs)
                best_ei = -np.inf
                x_best = lb + np.random.rand(self.dim) * (ub - lb)
                
                # Multi-start acquisition optimization
                for _ in range(8):
                    x0 = lb + np.random.rand(self.dim) * (ub - lb)
                    res = minimize(self._get_ei, x0, args=(self.rf, y_min), 
                                   bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if -res.fun > best_ei:
                        best_ei = -res.fun
                        x_best = res.x
                x = x_best
            
            y = func(x)
            x_obs.append(x)
            y_obs.append(y)
            
            # Update surrogate every iteration after sufficient data
            if len(y_obs) >= n_init:
                try:
                    self.rf.fit(np.array(x_obs), np.array(y_obs))
                except Exception:
                    pass
        
        idx = np.argmin(y_obs)
        return float(y_obs[idx]), np.array(x_obs[idx])