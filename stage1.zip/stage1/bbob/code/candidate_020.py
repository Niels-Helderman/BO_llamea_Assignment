import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e1)) + WhiteKernel(noise_level=1e-10)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        scale = ub - lb
        X_obs, y_obs = [], []
        best_y, best_x = np.inf, None

        n_init = max(2, min(15, self.budget // 5))
        for _ in range(n_init):
            x = lb + np.random.rand(self.dim) * scale
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y: best_y, best_x = y, x

        for i in range(n_init, self.budget):
            X_norm = (np.array(X_obs) - lb) / scale
            y = np.array(y_obs)
            
            # Refit frequency reduces to save compute, jitter for numerical stability
            self.gp.optimizer = "fmin_l_bfgs_b" if (i < 20 or i % 10 == 0) else None
            try:
                self.gp.fit(X_norm, y)
            except:
                pass

            # Adaptive beta schedule for UCB: explore early, exploit late
            beta = 2.0 * np.sqrt(np.log(i + 1))
            
            def ucb(x_norm):
                mu, sigma = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                return mu - beta * sigma

            best_acq = np.inf
            next_x_norm = np.random.rand(self.dim)
            
            # Multi-start acquisition optimization
            for _ in range(8):
                start = np.random.rand(self.dim)
                res = minimize(ucb, start, bounds=[(0, 1)] * self.dim, method='L-BFGS-B', tol=1e-3)
                if res.fun < best_acq:
                    best_acq, next_x_norm = res.fun, res.x

            # Safety check: avoid sampling too close to known points (jitter)
            dist = np.min(np.linalg.norm(X_norm - next_x_norm, axis=1))
            if dist < 0.05:
                next_x_norm = np.random.rand(self.dim)

            next_x = np.clip(lb + next_x_norm * scale, lb, ub)
            next_y = func(next_x)
            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y, best_x = next_y, next_x

        return float(best_y), best_x