import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.stats import norm
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Use Matern 5/2 as it is well-suited for BBOB smooth-ish functions
        # WhiteKernel provides stability against numerical noise in deterministic functions
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e1)) + WhiteKernel(noise_level=1e-10)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        scale = ub - lb
        
        X_obs, y_obs = [], []
        best_y = np.inf
        best_x = None

        # Enhanced LHS-like initialization: 20 points for better landscape capture
        n_init = min(20, self.budget // 4)
        for _ in range(n_init):
            x = lb + np.random.rand(self.dim) * scale
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y, best_x = y, x

        for i in range(n_init, self.budget):
            X_norm = (np.array(X_obs) - lb) / scale
            y = np.array(y_obs)
            
            # Refit every 4 steps early on, then every 8 to balance cost/accuracy
            self.gp.optimizer = "fmin_l_bfgs_b" if (i < 40 or i % 8 == 0) else None
            try:
                self.gp.fit(X_norm, y)
            except:
                pass

            def log_ei(x_norm):
                mu, sigma = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                sigma = np.clip(sigma, 1e-12, None)
                diff = best_y - mu
                z = diff / sigma
                # Log-EI is numerically more stable than standard EI
                log_acq = np.log(np.maximum(diff, 1e-30)) + norm.logcdf(z) + np.log(sigma + 1e-30)
                return -log_acq

            # Multi-start acquisition to avoid local traps
            best_acq = np.inf
            next_x_norm = np.random.rand(self.dim)
            starts = [np.random.rand(self.dim) for _ in range(10)]
            starts.append((best_x - lb) / scale)
            
            for s in starts:
                res = minimize(log_ei, s, bounds=[(0, 1)] * self.dim, method='L-BFGS-B', tol=1e-4)
                if res.fun < best_acq:
                    best_acq = res.fun
                    next_x_norm = res.x

            next_x = np.clip(lb + next_x_norm * scale, lb, ub)
            
            # Ensure we don't sample too close to existing points
            dist = np.min(np.linalg.norm(X_norm - next_x_norm, axis=1))
            if dist < 1e-3:
                next_x = lb + np.random.rand(self.dim) * scale

            next_y = func(next_x)
            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y, best_x = next_y, next_x

        return float(best_y), best_x