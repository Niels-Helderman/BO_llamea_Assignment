import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import norm

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=np.ones(dim)) + WhiteKernel(noise_level=1e-8)
        self.gpr = GaussianProcessRegressor(kernel=self.kernel, normalize_y=True, n_restarts_optimizer=0)

    def _get_ei(self, x, gpr, y_min):
        mu, std = gpr.predict(x.reshape(1, -1), return_std=True)
        std = np.maximum(std, 1e-12)
        imp = y_min - mu
        z = imp / std
        ei = imp * norm.cdf(z) + std * norm.pdf(z)
        return -ei[0]

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        x_obs, y_obs = [], []
        n_init = min(self.budget // 4, 2 * self.dim + 2)
        
        # Initialization
        for i in range(self.budget):
            if i < n_init:
                x = lb + np.random.rand(self.dim) * range_val
            else:
                # Acquisition optimization
                y_min = min(y_obs)
                best_ei = 0
                x_best = lb + np.random.rand(self.dim) * range_val
                
                # Multi-start gradient-based acquisition optimization
                for _ in range(5):
                    x0 = lb + np.random.rand(self.dim) * range_val
                    res = minimize(self._get_ei, x0, args=(self.gpr, y_min), bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if res.fun < best_ei:
                        best_ei = res.fun
                        x_best = res.x
                x = x_best

            y = func(x)
            x_obs.append(x)
            y_obs.append(y)
            
            # Periodically retrain GPR
            if len(y_obs) >= n_init and (len(y_obs) % 5 == 0 or len(y_obs) == n_init):
                try:
                    self.gpr.fit(np.array(x_obs), np.array(y_obs))
                except:
                    pass
        
        idx = np.argmin(y_obs)
        return float(y_obs[idx]), np.array(x_obs[idx])