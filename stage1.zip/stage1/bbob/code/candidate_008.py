import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Matern 5/2 is standard for BBOB; WhiteKernel handles numerical noise
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e1)) + WhiteKernel(noise_level=1e-8)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        X_obs, y_obs = [], []
        best_y, best_x = np.inf, None

        # Initialization: Latin Hypercube-like design (jittered grid) for better coverage
        n_init = max(2 * self.dim, min(15, self.budget // 4))
        for i in range(n_init):
            x = lb + (ub - lb) * (np.random.rand(self.dim) + np.arange(self.dim) / self.dim) % 1.0
            y = func(x)
            X_obs.append(x); y_obs.append(y)
            if y < best_y: best_y, best_x = y, x

        # Sequential Optimization
        for i in range(n_init, self.budget):
            X = (np.array(X_obs) - lb) / range_val
            y = np.array(y_obs)
            
            # Periodically re-optimize hyperparameters to save compute
            self.gp.optimizer = "fmin_l_bfgs_b" if (i % 8 == 0) else None
            try:
                self.gp.fit(X, y)
            except:
                pass # Use previous parameters if fitting fails

            # UCB acquisition: beta decreases as we gain confidence
            beta = 2.0 * np.log(i + 1)
            def ucb(x_norm):
                mu, std = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                return mu - beta * std

            # Multi-start acquisition optimization
            best_acq = np.inf
            next_x_norm = np.random.rand(self.dim)
            for _ in range(8):
                x0 = np.random.rand(self.dim)
                res = minimize(ucb, x0, bounds=[(0, 1)]*self.dim, method='L-BFGS-B', tol=1e-3)
                if res.fun < best_acq:
                    best_acq, next_x_norm = res.fun, res.x

            next_x = lb + next_x_norm * range_val
            
            # Safety fallback for duplicate points
            if np.any(np.all(np.isclose(X_obs, next_x), axis=1)):
                next_x = lb + np.random.rand(self.dim) * range_val
            
            next_y = func(next_x)
            X_obs.append(next_x); y_obs.append(next_y)
            if next_y < best_y: best_y, best_x = next_y, next_x

        return float(best_y), best_x