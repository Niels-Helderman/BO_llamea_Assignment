import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.stats import norm
from scipy.optimize import minimize
from scipy.stats import qmc

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Matern 5/2 is generally robust for BBOB functions
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=np.ones(dim)) + WhiteKernel(noise_level=1e-8)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=0.0, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        X_obs = []
        y_obs = []
        best_y = np.inf
        best_x = None

        # Initialization: Use Sobol sequence (LHS-like) for better space filling
        n_init = min(12, self.budget // 4)
        sampler = qmc.Sobol(d=self.dim, scramble=True)
        init_samples = sampler.random(n=n_init)
        
        for i in range(n_init):
            x = lb + init_samples[i] * range_val
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y = y
                best_x = x

        # Sequential Model-Based Optimization
        for i in range(n_init, self.budget):
            X_norm = (np.array(X_obs) - lb) / range_val
            y = np.array(y_obs)
            
            # Refit hyperparameters less frequently as data grows to save time
            optimize_hyper = (i < 20 or i % 10 == 0)
            self.gp.optimizer = "fmin_l_bfgs_b" if optimize_hyper else None
            try:
                self.gp.fit(X_norm, y)
            except:
                self.gp.kernel.set_params(**self.gp.kernel.get_params()) # Fallback to existing
            
            # Acquisition Function: Expected Improvement
            def ei(x_norm):
                mu, sigma = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                sigma = np.maximum(sigma, 1e-10)
                imp = best_y - mu
                z = imp / sigma
                return -(imp * norm.cdf(z) + sigma * norm.pdf(z))

            # Optimize Acquisition with Multi-start
            best_acq = 0.0
            next_x_norm = np.random.rand(self.dim)
            for _ in range(8):
                x0 = np.random.rand(self.dim)
                res = minimize(ei, x0, bounds=[(0, 1)] * self.dim, method='L-BFGS-B')
                if -res.fun > best_acq:
                    best_acq = -res.fun
                    next_x_norm = res.x

            next_x = lb + next_x_norm * range_val
            
            # Ensure we do not sample duplicates
            if np.any(np.all(np.abs(np.array(X_obs) - next_x) < 1e-6, axis=1)):
                next_x = lb + np.random.rand(self.dim) * range_val
            
            next_y = func(next_x)

            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y = next_y
                best_x = next_x

        return float(best_y), best_x