import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.stats import norm
from scipy.optimize import minimize
from scipy.stats import qmc

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Use Matern 5/2 as it is more robust to general BBOB functions than 2.5
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e1)) + WhiteKernel(noise_level=1e-8)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=0.0, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        X_obs = []
        y_obs = []
        best_y = np.inf
        best_x = None

        # Initialization: Use Latin Hypercube Sampling for better space-filling than random
        n_init = min(12, self.budget // 3)
        sampler = qmc.LatinHypercube(d=self.dim)
        sample = sampler.random(n=n_init)
        init_points = lb + sample * range_val

        for x in init_points:
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y = y
                best_x = x

        # Sequential Optimization
        for i in range(len(X_obs), self.budget):
            X = (np.array(X_obs) - lb) / range_val
            y = np.array(y_obs)
            
            # Fit GP: Re-optimize hyperparameters every 3 steps to keep pace with information gain
            optimize_hyper = (i % 3 == 0)
            self.gp.optimizer = "fmin_l_bfgs_b" if optimize_hyper else None
            try:
                self.gp.fit(X, y)
            except:
                pass

            # Acquisition Function: Expected Improvement
            def ei(x_norm):
                mu, sigma = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                sigma = np.maximum(sigma, 1e-12)
                imp = best_y - mu
                z = imp / sigma
                return -(imp * norm.cdf(z) + sigma * norm.pdf(z))

            # Optimize Acquisition with Multi-start
            best_acq = 0.0
            next_x_norm = np.random.rand(self.dim)
            
            # Start with Latin Hypercube for acquisition optimization
            acq_sampler = qmc.LatinHypercube(d=self.dim)
            seeds = acq_sampler.random(n=8)
            for x0 in seeds:
                res = minimize(ei, x0, bounds=[(0, 1)] * self.dim, method='L-BFGS-B')
                if -res.fun > best_acq:
                    best_acq = -res.fun
                    next_x_norm = res.x

            next_x = lb + next_x_norm * range_val
            
            # Fallback for numerical stability
            try:
                next_y = func(next_x)
            except:
                next_x = lb + np.random.rand(self.dim) * range_val
                next_y = func(next_x)

            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y = next_y
                best_x = next_x

        return float(best_y), best_x