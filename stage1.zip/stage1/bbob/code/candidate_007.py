import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from sklearn.ensemble import RandomForestRegressor
from scipy.stats import norm
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=np.ones(dim)) + WhiteKernel(noise_level=1e-7)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=0.0, normalize_y=True)
        self.rf = RandomForestRegressor(n_estimators=50, min_samples_split=3)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        X_obs, y_obs = [], []
        best_y, best_x = np.inf, None

        # Initialization: Use Sobol-like deterministic scattering
        n_init = min(12, self.budget // 4)
        for i in range(n_init):
            x = lb + (ub - lb) * (np.random.rand(self.dim) if i == 0 else np.mod(np.arange(i) * 0.61803398875, 1.0))[:self.dim]
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y, best_x = y, x

        for i in range(len(X_obs), self.budget):
            X = (np.array(X_obs) - lb) / range_val
            y = np.array(y_obs)
            
            # Ensemble modeling: GP for local trend, RF for global structure
            self.gp.fit(X, y)
            self.rf.fit(X, y)
            
            def acq(x_norm):
                x_norm = x_norm.reshape(1, -1)
                mu_gp, std_gp = self.gp.predict(x_norm, return_std=True)
                mu_rf = self.rf.predict(x_norm)
                mu = 0.7 * mu_gp + 0.3 * mu_rf
                sigma = np.maximum(std_gp, 1e-9)
                z = (best_y - mu) / sigma
                return -( (best_y - mu) * norm.cdf(z) + sigma * norm.pdf(z) )

            # Optimize acquisition with multi-start
            best_acq = np.inf
            next_x_norm = np.random.rand(self.dim)
            for _ in range(8):
                x0 = np.random.rand(self.dim)
                res = minimize(acq, x0, bounds=[(0, 1)] * self.dim, method='L-BFGS-B')
                if res.fun < best_acq:
                    best_acq, next_x_norm = res.fun, res.x
            
            next_x = lb + next_x_norm * range_val
            try:
                next_y = func(next_x)
            except:
                next_x = lb + np.random.rand(self.dim) * range_val
                next_y = func(next_x)

            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y, best_x = next_y, next_x

        return float(best_y), best_x