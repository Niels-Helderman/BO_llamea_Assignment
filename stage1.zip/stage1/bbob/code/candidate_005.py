import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import qmc

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=np.ones(dim)) + WhiteKernel(noise_level=1e-8)
        self.gpr = GaussianProcessRegressor(kernel=self.kernel, normalize_y=True, n_restarts_optimizer=0)

    def _ucb(self, x, gpr, beta, x_center, trust_region_size, lb, ub):
        mu, std = gpr.predict(x.reshape(1, -1), return_std=True)
        # Add constraint: stay within trust region
        if np.any(x < np.maximum(lb, x_center - trust_region_size)) or \
           np.any(x > np.minimum(ub, x_center + trust_region_size)):
            return 1e10
        return mu - beta * std

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        x_obs, y_obs = [], []
        
        # Initialization
        sampler = qmc.Sobol(d=self.dim, scramble=True)
        init_n = min(self.budget, 2 * self.dim + 4)
        sobol_points = sampler.random(n=init_n)
        
        x_center = None
        tr_size = 0.5
        success_count = 0
        failure_count = 0
        
        for i in range(self.budget):
            if i < init_n:
                x = lb + sobol_points[i] * (ub - lb)
            else:
                self.gpr.fit(np.array(x_obs), np.array(y_obs))
                beta = 2.0 * (1.0 - i / self.budget) + 0.5
                
                best_val = np.inf
                x_best = lb + np.random.rand(self.dim) * (ub - lb)
                
                # Multi-start acquisition optimization
                for _ in range(8):
                    x0 = np.clip(x_center + np.random.normal(0, tr_size/3, self.dim), lb, ub)
                    res = minimize(self._ucb, x0, args=(self.gpr, beta, x_center, tr_size, lb, ub), 
                                   bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if res.fun < best_val:
                        best_val, x_best = res.fun, res.x
                x = x_best

            y = func(x)
            if not np.isfinite(y): y = 1e10
            x_obs.append(x); y_obs.append(y)
            
            # Trust region logic
            if x_center is None or y < np.min(y_obs[:-1]):
                if x_center is not None: success_count += 1
                x_center = x
                failure_count = 0
            else:
                failure_count += 1
            
            if success_count >= 3:
                tr_size = min(0.5, tr_size * 1.2)
                success_count = 0
            if failure_count >= 5:
                tr_size = max(0.01, tr_size * 0.5)
                failure_count = 0
                if tr_size < 0.05:
                    x_center = x_obs[np.argmin(y_obs)]
                    tr_size = 0.5

        best_idx = np.argmin(y_obs)
        return float(y_obs[best_idx]), np.array(x_obs[best_idx])