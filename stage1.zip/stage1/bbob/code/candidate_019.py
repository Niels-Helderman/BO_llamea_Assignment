import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.stats import norm, qmc
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Use Matern 5/2 with optimized length scales for BBOB
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=[0.5]*dim) + WhiteKernel(noise_level=1e-10)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        scale = ub - lb
        
        X_obs, y_obs = [], []
        best_y = np.inf
        best_x = None

        # Use Sobol sequence for better space-filling coverage than random
        sampler = qmc.Sobol(d=self.dim, scramble=True)
        n_init = min(15, self.budget // 5)
        init_samples = sampler.random(n_init)
        
        for i in range(self.budget):
            if i < n_init:
                x_norm = init_samples[i]
            else:
                # Update GP and optimize acquisition
                X_norm = (np.array(X_obs) - lb) / scale
                y = np.array(y_obs)
                
                # Periodically re-optimize GP hyperparameters
                fit_optimizer = "fmin_l_bfgs_b" if (i % 10 == 0 or i == n_init) else None
                self.gp.optimizer = fit_optimizer
                try:
                    self.gp.fit(X_norm, y)
                except:
                    pass

                def log_ei(x_n):
                    mu, sigma = self.gp.predict(x_n.reshape(1, -1), return_std=True)
                    sigma = np.clip(sigma, 1e-12, None)
                    diff = best_y - mu
                    # Numerical log-EI calculation
                    z = diff / sigma
                    return -(np.log(np.maximum(diff, 1e-30)) + norm.logcdf(z) + np.log(sigma))

                # Multi-start acquisition with 8 candidates
                best_acq = np.inf
                x_norm = np.random.rand(self.dim)
                for start in np.random.rand(8, self.dim):
                    res = minimize(log_ei, start, bounds=[(0, 1)]*self.dim, method='L-BFGS-B', tol=1e-3)
                    if res.fun < best_acq:
                        best_acq, res.fun
                        x_norm = res.x
            
            # Convert normalized space back to real bounds
            x = np.clip(lb + x_norm * scale, lb, ub)
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y, best_x = y, x

        return float(best_y), best_x