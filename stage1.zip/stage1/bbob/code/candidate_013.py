import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.stats import norm
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Matern 2.5 is generally robust for BBOB functions
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e1)) + WhiteKernel(noise_level=1e-8)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=0.0, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        X_obs = []
        y_obs = []
        best_y = np.inf
        best_x = None

        # Increased initialization to 15 to capture landscape better early on
        n_init = min(15, self.budget // 3)
        for i in range(n_init):
            x = lb + (ub - lb) * np.random.rand(self.dim)
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y = y
                best_x = x

        for i in range(n_init, self.budget):
            X = np.array(X_obs)
            y = np.array(y_obs)
            
            # Periodically re-fit hyperparameters, but keep optimizer robust
            optimize_hyper = (i % 8 == 0)
            self.gp.optimizer = "fmin_l_bfgs_b" if optimize_hyper else None
            try:
                self.gp.fit((X - lb) / range_val, y)
            except:
                pass # Fallback to previous GP if fitting fails

            def ei(x_norm):
                mu, sigma = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                sigma = np.maximum(sigma, 1e-10)
                imp = best_y - mu
                z = imp / sigma
                return -(imp * norm.cdf(z) + sigma * norm.pdf(z))

            best_acq = np.inf
            next_x_norm = np.random.rand(self.dim)
            
            # Multi-start acquisition optimization to ensure we don't get stuck
            starts = [np.random.rand(self.dim) for _ in range(8)]
            starts.append((best_x - lb) / range_val) # Include best point
            
            for s in starts:
                res = minimize(ei, s, bounds=[(0, 1)] * self.dim, method='L-BFGS-B')
                if res.fun < best_acq:
                    best_acq = res.fun
                    next_x_norm = res.x

            next_x = np.clip(lb + next_x_norm * range_val, lb, ub)
            next_y = func(next_x)

            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y = next_y
                best_x = next_x

        return float(best_y), best_x