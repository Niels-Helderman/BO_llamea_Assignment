import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import qmc

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        # Robust kernel with small nugget to handle potential noise/numerical issues
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=np.ones(dim)) + WhiteKernel(noise_level=1e-10)
        self.gpr = GaussianProcessRegressor(kernel=self.kernel, normalize_y=True, n_restarts_optimizer=0)

    def _ucb(self, x, gpr, beta):
        mu, std = gpr.predict(x.reshape(1, -1), return_std=True)
        return mu - beta * std

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        
        x_obs = []
        y_obs = []
        
        # Sobol sequence for better space-filling coverage than pure random
        sampler = qmc.Sobol(d=self.dim, scramble=True)
        sobol_points = sampler.random(n=min(self.budget, 2 * self.dim + 8))
        
        for i in range(self.budget):
            if i < len(sobol_points):
                x = lb + sobol_points[i] * (ub - lb)
            else:
                # Update surrogate
                self.gpr.fit(np.array(x_obs), np.array(y_obs))
                
                # Adaptive beta schedule: high exploration early, low late
                progress = i / self.budget
                beta = 2.0 * (1.0 - progress) + 0.5
                
                # Global optimization of acquisition function via multi-start
                best_val = np.inf
                x_best = lb + np.random.rand(self.dim) * (ub - lb)
                
                for _ in range(8):
                    x0 = lb + np.random.rand(self.dim) * (ub - lb)
                    res = minimize(self._ucb, x0, args=(self.gpr, beta), bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if res.fun < best_val:
                        best_val = res.fun
                        x_best = res.x
                x = x_best
            
            # Observe
            y = func(x)
            
            # Ensure no crash if func returns weird values
            if not np.isfinite(y):
                y = 1e10
                
            x_obs.append(x)
            y_obs.append(y)
            
        best_idx = np.argmin(y_obs)
        return float(y_obs[best_idx]), np.array(x_obs[best_idx])