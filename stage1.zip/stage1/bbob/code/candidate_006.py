import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import qmc, norm

class BayesianOptimizer:
    def __init__(self, budget=600, dim=6):
        self.budget = budget
        self.dim = dim
        # Use WhiteKernel for numerical stability with deterministic functions
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=np.ones(dim)) + WhiteKernel(noise_level=1e-8)
        self.gpr = GaussianProcessRegressor(kernel=self.kernel, normalize_y=True, n_restarts_optimizer=0)
        self.fit_interval = 5

    def _log_ei(self, x, gpr, y_min):
        mu, std = gpr.predict(x.reshape(1, -1), return_std=True)
        std = np.maximum(std, 1e-12)
        diff = y_min - mu
        with np.errstate(divide='ignore'):
            z = diff / std
            log_ei = np.log(std) + norm.logcdf(z) + np.log(1 + (diff / std) * (norm.cdf(z) / norm.pdf(z)))
        return -np.exp(log_ei)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        x_obs, y_obs = [], []
        
        # Initial Sobol design: 2*dim + 4 provides enough points to estimate length scales early
        n_init = 2 * self.dim + 4
        sampler = qmc.Sobol(d=self.dim, scramble=True)
        init_points = sampler.random(n=n_init)
        
        for i in range(self.budget):
            if i < n_init:
                x = lb + init_points[i] * (ub - lb)
            else:
                if i % self.fit_interval == 0:
                    self.gpr.fit(np.array(x_obs), np.array(y_obs))
                
                y_min = np.min(y_obs)
                best_val, x_best = np.inf, None
                
                # Multi-start optimization of EI
                for _ in range(8):
                    x0 = lb + np.random.rand(self.dim) * (ub - lb)
                    res = minimize(self._log_ei, x0, args=(self.gpr, y_min), 
                                   bounds=list(zip(lb, ub)), method='L-BFGS-B')
                    if res.fun < best_val:
                        best_val, x_best = res.fun, res.x
                x = x_best if x_best is not None else lb + np.random.rand(self.dim) * (ub - lb)
            
            # Observe
            y = float(func(x))
            x_obs.append(x)
            y_obs.append(y if np.isfinite(y) else 1e10)
            
        best_idx = np.argmin(y_obs)
        return float(y_obs[best_idx]), np.array(x_obs[best_idx])