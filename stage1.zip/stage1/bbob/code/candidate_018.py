import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.stats import norm, qmc
from scipy.optimize import minimize

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Matern 5/2 is ideal for smooth BBOB; WhiteKernel adds robust numerical jitter
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e2)) + WhiteKernel(noise_level=1e-10)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        scale = ub - lb
        
        X_obs, y_obs = [], []
        best_y, best_x = np.inf, None

        # Latin Hypercube Sampling for optimal space-filling initialization
        n_init = max(2, min(self.budget // 5, 15))
        sampler = qmc.LatinHypercube(d=self.dim)
        init_points = qmc.scale(sampler.random(n=n_init), lb, ub)

        for x in init_points:
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y, best_x = y, x

        for i in range(len(X_obs), self.budget):
            X_norm = (np.array(X_obs) - lb) / scale
            y = np.array(y_obs)
            
            # Efficient refitting: full optimization initially, then periodic refit
            self.gp.optimizer = "fmin_l_bfgs_b" if (i < 20 or i % 10 == 0) else None
            try:
                self.gp.fit(X_norm, y)
            except:
                pass

            def ei(x_norm):
                mu, sigma = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                sigma = np.clip(sigma, 1e-12, None)
                diff = best_y - mu
                z = diff / sigma
                return -(diff * norm.cdf(z) + sigma * norm.pdf(z))

            # Multi-start acquisition optimization using LHS-distributed points + best_x
            best_acq = np.inf
            next_x_norm = np.random.rand(self.dim)
            seeds = qmc.LatinHypercube(d=self.dim).random(n=8)
            seeds = np.vstack([seeds, (best_x - lb) / scale])
            
            for s in seeds:
                res = minimize(ei, s, bounds=[(0, 1)] * self.dim, method='L-BFGS-B', tol=1e-5)
                if res.fun < best_acq:
                    best_acq, next_x_norm = res.fun, res.x

            next_x = np.clip(lb + next_x_norm * scale, lb, ub)
            
            # Distance-based fallback to prevent sampling too close to existing observations
            if np.min(np.linalg.norm(X_norm - next_x_norm, axis=1)) < 1e-3:
                next_x = lb + np.random.rand(self.dim) * scale

            next_y = func(next_x)
            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y, best_x = next_y, next_x

        return float(best_y), best_x