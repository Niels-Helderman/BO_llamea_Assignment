import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.optimize import minimize
from scipy.stats import qmc

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Use Matern 5/2 as it is a standard choice for BBOB functions.
        # WhiteKernel is used as a jitter term to handle deterministic noise numerically.
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale=np.ones(dim)) + WhiteKernel(noise_level=1e-8)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=0.0, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        X_obs, y_obs = [], []
        best_y, best_x = np.inf, None

        # 1. Initialization: Sobol Sequence (Low-discrepancy)
        n_init = max(2, min(15, self.budget // 4))
        sampler = qmc.Sobol(d=self.dim, scramble=True)
        samples = sampler.random(n_init)
        
        for i in range(self.budget):
            if i < n_init:
                x_norm = samples[i]
            else:
                # 2. Sequential Optimization
                X = (np.array(X_obs) - lb) / range_val
                y = np.array(y_obs)
                
                # Periodically re-fit hyperparameters
                optimize = (i % 8 == 0)
                self.gp.optimizer = "fmin_l_bfgs_b" if optimize else None
                try:
                    self.gp.fit(X, y)
                except:
                    pass

                # Adaptive Beta schedule: starts high, decays to prioritize exploitation
                beta = 2.0 * np.sqrt(np.log(i + 1))
                
                def ucb(x_n):
                    mu, std = self.gp.predict(x_n.reshape(1, -1), return_std=True)
                    return -(mu - beta * std) # Minimize negative UCB

                # Multi-start acquisition optimization
                best_acq = np.inf
                x_norm = np.random.rand(self.dim)
                for _ in range(8):
                    x0 = np.random.rand(self.dim)
                    res = minimize(ucb, x0, bounds=[(0, 1)]*self.dim, method='L-BFGS-B')
                    if res.fun < best_acq:
                        best_acq, x_norm = res.fun, res.x
            
            x = lb + x_norm * range_val
            try:
                y = float(func(x))
            except:
                y = np.inf
            
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y, best_x = y, x

        return float(best_y), best_x