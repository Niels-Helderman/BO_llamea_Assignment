import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from scipy.stats import norm
from scipy.optimize import minimize
from scipy.stats import qmc

class BayesianOptimizer:
    def __init__(self, budget, dim):
        self.budget = budget
        self.dim = dim
        # Matern 5/2 is standard for BBOB; WhiteKernel handles numeric stability
        self.kernel = ConstantKernel(1.0) * Matern(nu=2.5, length_scale_bounds=(1e-2, 1e2)) + WhiteKernel(noise_level=1e-10)
        self.gp = GaussianProcessRegressor(kernel=self.kernel, alpha=0.0, normalize_y=True, n_restarts_optimizer=0)

    def __call__(self, func):
        lb = np.array(func.bounds.lb)
        ub = np.array(func.bounds.ub)
        range_val = ub - lb
        
        X_obs, y_obs = [], []
        best_y, best_x = np.inf, None

        # Use Latin Hypercube Sampling for better coverage of the space
        n_init = min(12, self.budget // 4)
        sampler = qmc.LatinHypercube(d=self.dim)
        sample = sampler.random(n=n_init)
        init_points = qmc.scale(sample, lb, ub)

        for x in init_points:
            y = func(x)
            X_obs.append(x)
            y_obs.append(y)
            if y < best_y:
                best_y, best_x = y, x

        for i in range(len(X_obs), self.budget):
            X = (np.array(X_obs) - lb) / range_val
            y = np.array(y_obs)
            
            # Refit hyperparameters every few steps to save time; keep jitter tight
            if (i - n_init) % 5 == 0:
                self.gp.optimizer = "fmin_l_bfgs_b"
            else:
                self.gp.optimizer = None
            
            try:
                self.gp.fit(X, y)
            except:
                pass 

            def ei(x_norm):
                mu, sigma = self.gp.predict(x_norm.reshape(1, -1), return_std=True)
                sigma = np.clip(sigma, 1e-12, None)
                imp = best_y - mu
                z = imp / sigma
                return -(imp * norm.cdf(z) + sigma * norm.pdf(z))

            # Multi-start acquisition optimization
            best_acq = np.inf
            next_x_norm = np.random.rand(self.dim)
            
            # Combine random search with local optimization for robust acquisition search
            seeds = [np.random.rand(self.dim) for _ in range(10)]
            seeds.append((best_x - lb) / range_val)
            
            for s in seeds:
                res = minimize(ei, s, bounds=[(0, 1)]*self.dim, method='L-BFGS-B', tol=1e-4)
                if res.fun < best_acq:
                    best_acq, next_x_norm = res.fun, res.x

            next_x = np.clip(lb + next_x_norm * range_val, lb, ub)
            
            # Fallback if proposal is too close to existing point
            if np.min(np.linalg.norm(X - next_x_norm, axis=1)) < 1e-3:
                next_x = lb + np.random.rand(self.dim) * range_val
            
            next_y = func(next_x)
            X_obs.append(next_x)
            y_obs.append(next_y)
            if next_y < best_y:
                best_y, best_x = next_y, next_x

        return float(best_y), best_x